import { fal } from '@fal-ai/client';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { prompt, ratio = '16:9 Landscape', quality = 'Standard' } = req.body || {};
    if (!prompt || !prompt.trim()) return res.status(400).json({ error: 'Prompt is required' });
    if (!process.env.FAL_KEY) return res.status(500).json({ error: 'FAL_KEY is not configured on the server.' });

    fal.config({ credentials: process.env.FAL_KEY });

    const aspect_ratio = ratio.includes('9:16') ? '9:16' : ratio.includes('1:1') ? '1:1' : '16:9';
    const result = await fal.subscribe('fal-ai/wan/v2.2-a14b/text-to-video', {
      input: {
        prompt: prompt.trim(),
        aspect_ratio
      },
      logs: false
    });

    const videoUrl = result?.data?.video?.url;
    if (!videoUrl) return res.status(502).json({ error: 'Video was generated but no video URL was returned.' });

    return res.status(200).json({ videoUrl, quality, aspect_ratio });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err?.message || 'Video generation failed.' });
  }
}
